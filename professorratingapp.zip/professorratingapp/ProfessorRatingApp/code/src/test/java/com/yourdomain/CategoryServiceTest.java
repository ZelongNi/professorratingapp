package com.yourdomain;

import com.yourdomain.entities.Category;
import com.yourdomain.util.StorageService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

public class CategoryServiceTest {
    private CategoryService categoryService;

    @BeforeEach
    void setUp() {
        // Create a new CategoryService instance for each test
        categoryService = new CategoryService(new StorageService());
    }

    @Test
    void addCategory_shouldAddCategoryToList() {
        // Arrange
        String name = "Test Category";
        String description = "Test Description";

        // Act
        Category addedCategory = categoryService.addCategory(name, description);

        // Assert
        assertNotNull(addedCategory);
        assertEquals(name, addedCategory.getName());
        assertEquals(description, addedCategory.getDescription());

        List<Category> allCategories = categoryService.getAllCategories();
        assertTrue(allCategories.contains(addedCategory));
    }

    @Test
    void editCategory_shouldEditCategoryInList() {
        // Arrange
        String originalName = "Original Category";
        String originalDescription = "Original Description";
        Category originalCategory = categoryService.addCategory(originalName, originalDescription);

        String newName = "Updated Category";
        String newDescription = "Updated Description";

        // Act
        Category updatedCategory = categoryService.editCategory(originalCategory.getId(), newName, newDescription);

        // Assert
        assertNotNull(updatedCategory);
        assertEquals(newName, updatedCategory.getName());
        assertEquals(newDescription, updatedCategory.getDescription());

        List<Category> allCategories = categoryService.getAllCategories();
        assertTrue(allCategories.contains(updatedCategory));
        assertFalse(allCategories.contains(originalCategory));
    }

    @Test
    void deleteCategory_shouldRemoveCategoryFromList() {
        // Arrange
        String name = "Category to be deleted";
        String description = "Description to be deleted";
        Category categoryToDelete = categoryService.addCategory(name, description);

        // Act
        categoryService.deleteCategory(categoryToDelete.getId());

        // Assert
        List<Category> allCategories = categoryService.getAllCategories();
        assertFalse(allCategories.contains(categoryToDelete));
    }
}
