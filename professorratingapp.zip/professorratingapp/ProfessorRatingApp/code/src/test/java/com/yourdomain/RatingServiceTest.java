package com.yourdomain;

import com.yourdomain.entities.Rating;
import com.yourdomain.services.RatingService;
import com.yourdomain.util.StorageService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

public class RatingServiceTest {
    private RatingService ratingService;

    @BeforeEach
    void setUp() {
        // Create a new RatingService instance for each test
        ratingService = new RatingService(new StorageService());
    }

    @Test
    void addRating_shouldAddRatingToList() {
        // Arrange
        UUID professorId = UUID.randomUUID();
        UUID categoryId = UUID.randomUUID();
        int value = 5;

        // Act
        Rating addedRating = ratingService.addRating(professorId, categoryId, value);

        // Assert
        assertNotNull(addedRating);
        assertEquals(professorId, addedRating.getProfessorId());
        assertEquals(categoryId, addedRating.getCategoryId());
        assertEquals(value, addedRating.getValue());

        List<Rating> allRatings = ratingService.getAllRatings();
        assertTrue(allRatings.contains(addedRating));
    }

    @Test
    void editRating_shouldEditRatingInList() {
        // Arrange
        UUID originalProfessorId = UUID.randomUUID();
        UUID originalCategoryId = UUID.randomUUID();
        int originalValue = 3;

        Rating originalRating = ratingService.addRating(originalProfessorId, originalCategoryId, originalValue);

        int newValue = 4;

        // Act
        Rating updatedRating = ratingService.editRating(originalRating.getId(), newValue);

        // Assert
        assertNotNull(updatedRating);
        assertEquals(newValue, updatedRating.getValue());

        List<Rating> allRatings = ratingService.getAllRatings();
        assertTrue(allRatings.contains(updatedRating));
        assertFalse(allRatings.contains(originalRating));
    }

    @Test
    void deleteRating_shouldRemoveRatingFromList() {
        // Arrange
        UUID professorId = UUID.randomUUID();
        UUID categoryId = UUID.randomUUID();
        int value = 2;

        Rating ratingToDelete = ratingService.addRating(professorId, categoryId, value);

        // Act
        ratingService.deleteRating(ratingToDelete.getId());

        // Assert
        List<Rating> allRatings = ratingService.getAllRatings();
        assertFalse(allRatings.contains(ratingToDelete));
    }
}
