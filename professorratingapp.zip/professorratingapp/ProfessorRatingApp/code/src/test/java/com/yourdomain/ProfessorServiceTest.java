package com.yourdomain;

import com.yourdomain.entities.Professor;
import com.yourdomain.services.ProfessorService;
import com.yourdomain.util.StorageService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class ProfessorServiceTest {
    private ProfessorService professorService;

    @BeforeEach
    void setUp() {
        // Create a new ProfessorService instance for each test
        professorService = new ProfessorService(new StorageService());
    }

    @Test
    void addProfessor_shouldAddProfessorToList() {
        // Arrange
        String name = "Test Professor";

        // Act
        Professor addedProfessor = professorService.addProfessor(name);

        // Assert
        assertNotNull(addedProfessor);
        assertEquals(name, addedProfessor.getName());

        List<Professor> allProfessors = professorService.getAllProfessors();
        assertTrue(allProfessors.contains(addedProfessor));
    }

    @Test
    void editProfessor_shouldEditProfessorInList() {
        // Arrange
        String originalName = "Original Professor";
        Professor originalProfessor = professorService.addProfessor(originalName);

        String newName = "Updated Professor";

        // Act
        Professor updatedProfessor = professorService.editProfessor(originalProfessor.getId(), newName);

        // Assert
        assertNotNull(updatedProfessor);
        assertEquals(newName, updatedProfessor.getName());

        List<Professor> allProfessors = professorService.getAllProfessors();
        assertTrue(allProfessors.contains(updatedProfessor));
        assertFalse(allProfessors.contains(originalProfessor));
    }

    @Test
    void deleteProfessor_shouldRemoveProfessorFromList() {
        // Arrange
        String name = "Professor to be deleted";
        Professor professorToDelete = professorService.addProfessor(name);

        // Act
        professorService.deleteProfessor(professorToDelete.getId());

        // Assert
        List<Professor> allProfessors = professorService.getAllProfessors();
        assertFalse(allProfessors.contains(professorToDelete));
    }
}
