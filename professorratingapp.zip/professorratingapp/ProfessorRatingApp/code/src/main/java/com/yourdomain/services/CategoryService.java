package com.yourdomain.services;

import com.yourdomain.entities.Category;
import com.yourdomain.util.StorageService;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class CategoryService {
    private List<Category> categories; // Should be replaced with a proper database in a real app
    private StorageService storageService;

    public CategoryService(StorageService storageService) {
        this.storageService = storageService;
        this.categories = storageService.readCategories();
    }

    public Category addCategory(String name, String description) {
        UUID newId = UUID.randomUUID();
        Category newCategory = new Category(newId, name, description);
        categories.add(newCategory);
        storageService.writeCategories(categories);
        return newCategory;
    }

    public Category editCategory(UUID id, String newName, String newDescription) {
        for (Category category : categories) {
            if (category.getId().equals(id)) {
                category.setName(newName);
                category.setDescription(newDescription);
                storageService.writeCategories(categories);
                return category;
            }
        }
        return null; // or throw an exception
    }

    public void deleteCategory(UUID id) {
        categories = categories.stream()
                .filter(category -> !category.getId().equals(id))
                .collect(Collectors.toList());
        storageService.writeCategories(categories);
    }

    public List<Category> getAllCategories() {
        return categories;
    }

    public Category findCategoryById(UUID categoryId) {
        for (Category category : categories) {
            if (category.getId().equals(categoryId)) {
                return category;
            }
        }
        return null;
    }
}

