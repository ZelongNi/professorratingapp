package com.yourdomain;

import com.yourdomain.entities.Category;
import com.yourdomain.entities.Professor;
import com.yourdomain.entities.Rating;
import com.yourdomain.services.CategoryService;
import com.yourdomain.services.ProfessorService;
import com.yourdomain.services.RatingService;
import com.yourdomain.util.StorageService;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Scanner;
import java.util.UUID;

public class Main {
    private static final ProfessorService professorService = new ProfessorService(new StorageService());
    private static final RatingService ratingService = new RatingService(new StorageService());
    private static final CategoryService categoryService = new CategoryService(new StorageService());

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String userInput;

        System.out.println("Welcome to the Computer Science Professor Rating App!");

        do {
            printMainMenu();

            userInput = scanner.nextLine().toUpperCase();

            switch (userInput) {
                case "1":
                    manageProfessors(scanner);
                    break;
                case "2":
                    manageRatings(scanner);
                    break;
                case "3":
                    manageCategories(scanner);
                    break;
                case "Q":
                    System.out.println("Exiting the application.");
                    break;
                default:
                    System.out.println("Invalid input. Please try again.");
            }
        } while (!userInput.equals("Q"));

        scanner.close();
    }

    private static void printMainMenu() {
        System.out.println("\n=== Main Menu ===");
        System.out.println("1: Manage Professors");
        System.out.println("2: Manage Ratings");
        System.out.println("3: Manage Categories");
        System.out.println("Q: Quit");
        System.out.print("Enter your choice: ");
    }

    private static void manageProfessors(Scanner scanner) {
        System.out.println("\n=== Professor Management ===");
        System.out.println("1: Add Professor");
        System.out.println("2: Edit Professor");
        System.out.println("3: Delete Professor");
        System.out.println("4: View All Professors");
        System.out.println("Q: Back to Main Menu");

        String choice = scanner.nextLine();

        switch (choice) {
            case "1":
                addProfessor(scanner);
                break;
            case "2":
                editProfessor(scanner);
                break;
            case "3":
                deleteProfessor(scanner);
                break;
            case "4":
                viewAllProfessors();
                break;
            case "Q":
                System.out.println("Returning to the main menu.");
                break;
            default:
                System.out.println("Invalid input. Please try again.");
        }
    }

    private static void addProfessor(Scanner scanner) {
        System.out.print("Enter professor name: ");
        String professorName = scanner.nextLine();
        Professor addedProfessor = professorService.addProfessor(professorName);
        System.out.println("Professor added: " + addedProfessor.getName());
    }

    private static void editProfessor(Scanner scanner) {
        System.out.print("Enter professor ID to edit: ");
        UUID professorIdToEdit = UUID.fromString(scanner.nextLine());
        System.out.print("Enter new professor name: ");
        String newProfessorName = scanner.nextLine();
        Professor editedProfessor = professorService.editProfessor(professorIdToEdit, newProfessorName);
        if (editedProfessor != null) {
            System.out.println("Professor edited: " + editedProfessor.getName());
        } else {
            System.out.println("Professor not found.");
        }
    }

    private static void deleteProfessor(Scanner scanner) {
        System.out.print("Enter professor ID to delete: ");
        UUID professorIdToDelete = UUID.fromString(scanner.nextLine());
        professorService.deleteProfessor(professorIdToDelete);
        System.out.println("Professor deleted.");
    }

    private static void viewAllProfessors() {
        List<Professor> allProfessors = professorService.getAllProfessors();
        for (Professor professor : allProfessors) {
            System.out.println("ID: " + professor.getId() + " | Name: " + professor.getName());
        }
    }

    private static void manageRatings(Scanner scanner) {
        System.out.println("\n=== Rating Management ===");
        System.out.println("1: Add Rating");
        System.out.println("2: Edit Rating");
        System.out.println("3: Delete Rating");
        System.out.println("4: View All Ratings");
        System.out.println("Q: Back to Main Menu");

        String choice = scanner.nextLine();

        switch (choice) {
            case "1":
                addRating(scanner);
                break;
            case "2":
                editRating(scanner);
                break;
            case "3":
                deleteRating(scanner);
                break;
            case "4":
                viewAllRatings();
                break;
            case "Q":
                System.out.println("Returning to the main menu.");
                break;
            default:
                System.out.println("Invalid input. Please try again.");
        }
    }

    private static void addRating(Scanner scanner) {
        System.out.println("Professors:");
        viewAllProfessors();
        System.out.print("Enter the ID of the professor: ");
        UUID professorId = UUID.fromString(scanner.nextLine());
        Professor professor = professorService.findProfessorById(professorId);

        if (professor != null) {
            System.out.println("Categories:");
            viewAllCategories();
            System.out.print("Enter the ID of the category: ");
            UUID categoryId = UUID.fromString(scanner.nextLine());
            Category category = categoryService.findCategoryById(categoryId);

            if (category != null) {
                System.out.print("Enter the rating value (1-5): ");
                int ratingValue = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character
                Rating newRating = ratingService.addRating(professorId, categoryId, ratingValue);
                System.out.println("Rating added successfully!");
            } else {
                System.out.println("Category not found with ID: " + categoryId);
            }
        } else {
            System.out.println("Professor not found with ID: " + professorId);
        }
    }

    private static void editRating(Scanner scanner) {
        System.out.println("=== Edit Rating ===");
        System.out.println("Enter the ID of the rating to edit: ");
        UUID ratingIdToEdit = UUID.fromString(scanner.nextLine());
        Rating ratingToEdit = ratingService.findRatingById(ratingIdToEdit);

        if (ratingToEdit != null) {
            System.out.println("Enter the new rating value (1-5): ");
            int newRatingValue = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character
            ratingService.editRating(ratingIdToEdit, newRatingValue);
            System.out.println("Rating edited successfully!\n");
        } else {
            System.out.println("Rating not found with ID: " + ratingIdToEdit + "\n");
        }
    }

    private static void deleteRating(Scanner scanner) {
        System.out.println("=== Delete Rating ===");
        System.out.println("Enter the ID of the rating to delete: ");
        UUID ratingIdToDelete = UUID.fromString(scanner.nextLine());
        Rating ratingToDelete = ratingService.findRatingById(ratingIdToDelete);

        if (ratingToDelete != null) {
            ratingService.deleteRating(ratingIdToDelete);
            System.out.println("Rating deleted successfully!\n");
        } else {
            System.out.println("Rating not found with ID: " + ratingIdToDelete + "\n");
        }
    }

    private static void viewAllRatings() {
        List<Rating> allRatings = ratingService.getAllRatings();
        for (Rating rating : allRatings) {
            System.out.println("Professor ID: " + rating.getProfessorId() +
                    " | Category ID: " + rating.getCategoryId() +
                    " | Rating Value: " + rating.getValue());
        }
    }

    private static void manageCategories(Scanner scanner) {
        System.out.println("\n=== Category Management ===");
        System.out.println("1: Add Category");
        System.out.println("2: Edit Category");
        System.out.println("3: Delete Category");
        System.out.println("4: View All Categories");
        System.out.println("Q: Back to Main Menu");

        String choice = scanner.nextLine();

        switch (choice) {
            case "1":
                addCategory(scanner);
                break;
            case "2":
                editCategory(scanner);
                break;
            case "3":
                deleteCategory(scanner);
                break;
            case "4":
                viewAllCategories();
                break;
            case "Q":
                System.out.println("Returning to the main menu.");
                break;
            default:
                System.out.println("Invalid input. Please try again.");
        }
    }

    private static void addCategory(Scanner scanner) {
        System.out.print("Enter category name: ");
        String categoryName = scanner.nextLine();
        System.out.print("Enter category description: ");
        String categoryDescription = scanner.nextLine();
        Category addedCategory = categoryService.addCategory(categoryName, categoryDescription);
        System.out.println("Category added: " + addedCategory.getName());
    }

    private static void editCategory(Scanner scanner) {
        System.out.println("=== Edit Category ===");
        System.out.println("Enter the ID of the category to edit: ");
        UUID categoryIdToEdit = UUID.fromString(scanner.nextLine());
        Category categoryToEdit = categoryService.findCategoryById(categoryIdToEdit);

        if (categoryToEdit != null) {
            System.out.println("Enter the new name for the category: ");
            String newCategoryName = scanner.nextLine();
            System.out.println("Enter the new description for the category: ");
            String newCategoryDescription = scanner.nextLine();
            categoryService.editCategory(categoryIdToEdit, newCategoryName, newCategoryDescription);
            System.out.println("Category edited successfully!\n");
        } else {
            System.out.println("Category not found with ID: " + categoryIdToEdit + "\n");
        }
    }

    private static void deleteCategory(Scanner scanner) {
        System.out.println("=== Delete Category ===");
        System.out.println("Enter the ID of the category to delete: ");
        UUID categoryIdToDelete = UUID.fromString(scanner.nextLine());
        Category categoryToDelete = categoryService.findCategoryById(categoryIdToDelete);

        if (categoryToDelete != null) {
            categoryService.deleteCategory(categoryIdToDelete);
            System.out.println("Category deleted successfully!\n");
        } else {
            System.out.println("Category not found with ID: " + categoryIdToDelete + "\n");
        }
    }

    private static void viewAllCategories() {
        List<Category> allCategories = categoryService.getAllCategories();
        for (Category category : allCategories) {
            System.out.println("ID: " + category.getId() +
                    " | Name: " + category.getName() +
                    " | Description: " + category.getDescription());
        }
    }
}
