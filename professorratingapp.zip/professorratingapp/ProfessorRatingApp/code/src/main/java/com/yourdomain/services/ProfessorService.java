package com.yourdomain.services;
import com.yourdomain.entities.*;
import com.yourdomain.util.StorageService;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class ProfessorService {
    private List<Professor> professors; // Should be replaced with a proper database in a real app
    private StorageService storageService;

    public ProfessorService(StorageService storageService) {
        this.storageService = storageService;
        this.professors = storageService.readProfessors();
    }

    public Professor addProfessor(String name) {
        UUID newId = UUID.randomUUID();
        Professor newProfessor = new Professor(newId, name, null);
        professors.add(newProfessor);
        storageService.writeProfessors(professors);
        return newProfessor;
    }

    public Professor editProfessor(UUID id, String newName) {
        for (Professor professor : professors) {
            if (professor.getId().equals(id)) {
                professor.setName(newName);
                storageService.writeProfessors(professors);
                return professor;
            }
        }
        return null; // or throw an exception
    }

    public void deleteProfessor(UUID id) {
        professors = professors.stream()
                .filter(professor -> !professor.getId().equals(id))
                .collect(Collectors.toList());
        storageService.writeProfessors(professors);
    }

    public List<Professor> getAllProfessors() {
        return professors;
    }

    public Professor getProfessor(UUID id) {
        return professors.stream()
                .filter(professor -> professor.getId().equals(id))
                .findFirst()
                .orElse(null); // or throw an exception
    }

    public Professor findProfessorById(UUID professorId) {
        for (Professor professor : professors) {
            if (professor.getId().equals(professorId)) {
                return professor;
            }
        }
        return null;
    }
}

