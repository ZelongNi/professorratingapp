package com.yourdomain.entities;

import java.util.UUID;

public class Rating {
    private UUID id;
    private UUID professorId;
    private UUID categoryId;
    private int value;

    public Rating(UUID id, UUID professorId, UUID categoryId, int value) {
        this.id = id;
        this.professorId = professorId;
        this.categoryId = categoryId;
        this.value = value;
    }

    // Getters
    public UUID getId() {
        return id;
    }

    public UUID getProfessorId() {
        return professorId;
    }

    public UUID getCategoryId() {
        return categoryId;
    }

    public int getValue() {
        return value;
    }

    // Setters
    public void setId(UUID id) {
        this.id = id;
    }

    public void setProfessorId(UUID professorId) {
        this.professorId = professorId;
    }

    public void setCategoryId(UUID categoryId) {
        this.categoryId = categoryId;
    }

    public void setValue(int value) {
        this.value = value;
    }
}

