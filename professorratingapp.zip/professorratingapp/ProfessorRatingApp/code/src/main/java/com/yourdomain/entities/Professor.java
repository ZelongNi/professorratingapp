package com.yourdomain.entities;

import java.util.List;
import java.util.UUID;

public class Professor {
    private UUID id;
    private String name;
    private List<UUID> ratingIds; // Store only IDs to simplify JSON structure

    public Professor(UUID id, String name, List<UUID> ratingIds) {
        this.id = id;
        this.name = name;
        this.ratingIds = ratingIds;
    }

    // Getters
    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<UUID> getRatingIds() {
        return ratingIds;
    }

    // Setters
    public void setId(UUID id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRatingIds(List<UUID> ratingIds) {
        this.ratingIds = ratingIds;
    }
}
