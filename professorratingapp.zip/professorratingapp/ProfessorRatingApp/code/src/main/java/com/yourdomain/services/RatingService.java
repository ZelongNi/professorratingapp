package com.yourdomain.services;

import com.yourdomain.entities.Rating;
import com.yourdomain.util.StorageService;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class RatingService {
    private List<Rating> ratings; // Should be replaced with a proper database in a real app
    private StorageService storageService;

    public RatingService(StorageService storageService) {
        this.storageService = storageService;
        this.ratings = storageService.readRatings();
    }

    public Rating addRating(UUID professorId, UUID categoryId, int value) {
        UUID newId = UUID.randomUUID();
        Rating newRating = new Rating(newId, professorId, categoryId, value);
        ratings.add(newRating);
        storageService.writeRatings(ratings);
        return newRating;
    }

    public Rating editRating(UUID id, int newValue) {
        for (Rating rating : ratings) {
            if (rating.getId().equals(id)) {
                rating.setValue(newValue);
                storageService.writeRatings(ratings);
                return rating;
            }
        }
        return null; // or throw an exception
    }

    public void deleteRating(UUID id) {
        ratings = ratings.stream()
                .filter(rating -> !rating.getId().equals(id))
                .collect(Collectors.toList());
        storageService.writeRatings(ratings);
    }

    public List<Rating> getAllRatings() {
        return ratings;
    }
    
    public List<Rating> getRatingsByProfessor(UUID professorId) {
        return ratings.stream()
                .filter(rating -> rating.getProfessorId().equals(professorId))
                .collect(Collectors.toList());
    }

    public Rating findRatingById(UUID ratingId) {
        for (Rating rating : ratings) {
            if (rating.getId().equals(ratingId)) {
                return rating;
            }
        }
        return null;
    }
}
