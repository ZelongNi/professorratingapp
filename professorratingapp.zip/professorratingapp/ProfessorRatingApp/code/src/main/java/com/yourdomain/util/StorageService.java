package com.yourdomain.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.yourdomain.entities.Category;
import com.yourdomain.entities.Professor;
import com.yourdomain.entities.Rating;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class StorageService {
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final String professorsFilePath = "data/professors.json";
    private final String ratingsFilePath = "data/ratings.json";
    private final String categoriesFilePath = "data/categories.json";

    // Professors
    public List<Professor> readProfessors() {
        return readListFromFile(professorsFilePath, new TypeReference<>() {});
    }

    public void writeProfessors(List<Professor> professors) {
        writeListToFile(professorsFilePath, professors);
    }

    // Ratings
    public List<Rating> readRatings() {
        return readListFromFile(ratingsFilePath, new TypeReference<>() {});
    }

    public void writeRatings(List<Rating> ratings) {
        writeListToFile(ratingsFilePath, ratings);
    }

    // Categories
    public List<Category> readCategories() {
        return readListFromFile(categoriesFilePath, new TypeReference<>() {});
    }

    public void writeCategories(List<Category> categories) {
        writeListToFile(categoriesFilePath, categories);
    }

    // Generic read method
    private <T> List<T> readListFromFile(String filePath, TypeReference<List<T>> typeReference) {
        try {
            File file = new File(filePath);
            if (file.exists()) {
                return objectMapper.readValue(file, typeReference);
            }
        } catch (IOException e) {
            handleException("Error reading from file: " + filePath, e);
        }
        return new ArrayList<>();
    }

    // Generic write method
    private <T> void writeListToFile(String filePath, List<T> list) {
        try {
            File file = new File(filePath);
            objectMapper.writeValue(file, list);
        } catch (IOException e) {
            handleException("Error writing to file: " + filePath, e);
        }
    }

    private void handleException(String message, Exception e) {
        // Log the exception or handle it based on your logging strategy
        System.err.println(message);
        e.printStackTrace();
    }
}
